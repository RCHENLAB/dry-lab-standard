function commonSubmitArgs = getCommonSubmitArgs(cluster, numWorkers)
% Get any additional submit arguments for the Slurm sbatch command
% that are common to both independent and communicating jobs.

% Copyright 2016-2019 The MathWorks, Inc.

% wiki: https://www.hpc.iastate.edu/

commonSubmitArgs = '';

% Number of cores/node
ppn = validatedPropValue(cluster, 'ProcsPerNode', 'double');
if ppn>0
    % Don't request more cores/node than workers
    ppn = min(numWorkers,ppn);
    commonSubmitArgs = sprintf('%s --ntasks-per-node=%d',commonSubmitArgs,ppn);
end
commonSubmitArgs = sprintf('%s --ntasks-per-core=1',commonSubmitArgs);


%% REQUIRED

% Number of Nodes
nn = validatedPropValue(cluster, 'NumNodes', 'double');
if ~isempty(nn)
    commonSubmitArgs = sprintf('%s -N %d',commonSubmitArgs,nn);
else
	emsg = sprintf(['\n\t>> %% Must set NumNodes.  E.g.\n\n', ...
                    '\t>> c = parcluster;\n', ...
                    '\t>> %% Set NumNodes to 1\n', ...
                    '\t>> c.AdditionalProperties.NumNodes = 1;\n', ...
                    '\t>> c.saveProfile\n\n']);
    error(emsg) %#ok<SPERR>
end

% Walltime
wt = validatedPropValue(cluster, 'WallTime', 'char');
if ~isempty(wt)
    commonSubmitArgs = [commonSubmitArgs ' -t ' wt];
else
	emsg = sprintf(['\n\t>> %% Must set WallTime.  E.g.\n\n', ...
                    '\t>> c = parcluster;\n', ...
                    '\t>> %% Set WallTime to 5 hours\n', ...
                    '\t>> c.AdditionalProperties.WallTime = ''05:00:00'';\n', ...
                    '\t>> c.saveProfile\n\n']);
    error(emsg) %#ok<SPERR>
end

%% OPTIONAL

% Partition 
qn = validatedPropValue(cluster, 'QueueName', 'char');
if ~isempty(qn)
    commonSubmitArgs = [commonSubmitArgs ' -p ' qn];
end

% GPUs Per Node
%ngpus = validatedPropValue(cluster, 'GpusPerNode', 'double');
%if ngpus>0
%    commonSubmitArgs = sprintf('%s --gres=gpu:%d',commonSubmitArgs,ngpus);
%end

% Physical Memory used by a single core
mu = validatedPropValue(cluster, 'MemUsage', 'char');
if ~isempty(mu)
    commonSubmitArgs = [commonSubmitArgs ' --mem-per-cpu=' mu];
end

% Email notification
ea = validatedPropValue(cluster, 'EmailAddress', 'char');
if ~isempty(ea)
    commonSubmitArgs = [commonSubmitArgs ' --mail-type=ALL --mail-user=' ea];
end

% Catch-all
asa = validatedPropValue(cluster, 'AdditionalSubmitArgs', 'char');
if ~isempty(asa)
    commonSubmitArgs = [commonSubmitArgs ' ' asa];
end

commonSubmitArgs = strtrim(commonSubmitArgs);
